#! /usr/bin/env python

import rospy
from nav_msgs.msg import Odometry
from tf.transformations import euler_from_quaternion
from geometry_msgs.msg import Point
from geometry_msgs.msg import Twist
from math import atan2
import numpy as np

x = 0
y = 0
theta = 0

def callback(msg):
    global x, y, theta

    x = msg.pose.pose.position.x
    print 'Current position of x: ' +str(msg.pose.pose.position.x)
    y = msg.pose.pose.position.y
    print 'Current position of y: ' +str(msg.pose.pose.position.y)
    orientation_q = msg.pose.pose.orientation
    orientation_list = [orientation_q.x, orientation_q.y, orientation_q.z, orientation_q.w]
    (roll, pitch, theta) = euler_from_quaternion (orientation_list)
    print 'Orientation of the robot: ' +str(msg.pose.pose.orientation.w)
    print 'Speed of the robot: ' +str(twist.linear.x)
    print '.---------------------\n'
    print 'Desired position of x: ' +str(point.x)
    print 'Desired position of y: ' +str(point.y)
    print '----------------------\n'

def main():
    global point_number, position_x, point_list, position_y

    if point_number < len(point_list):
        point.x = point_list[point_number][0] # x coordinate for goal
        point.y = point_list[point_number][1] # y coordinate for goal
    else:
        print 'Goal Reached'

    position_x = point.x - x
    position_y = point.y - y
    angle_towards_goal = atan2 (position_y, position_x) 
    distance_to_goal = np.sqrt(position_x*position_x + position_y*position_y)

    if distance_to_goal >= 0.3:
        if abs(angle_towards_goal - theta) > 0.2:
            twist.linear.x = 0.0
            twist.angular.z = 0.5

        else:
            twist.linear.x = 0.2
            twist.angular.z = 0.0
        pub.publish(twist)

    elif point_number == 1:
        twist.linear.x = 0.0
        twist.angular.z = 0.0
        pub.publish(twist)  

    else:
        point_number += 1

rospy.init_node ("pioneer_position")
sub = rospy.Subscriber("pioneer/odom", Odometry, callback)
pub = rospy.Publisher("pioneer/cmd_vel",Twist, queue_size=1)
twist = Twist()
rospy.Rate(4)
point = Point ()

point_list = [(22,11), (22,-11)]
point_number = 0

while not rospy.is_shutdown():
    main()
    rospy.sleep(0.01)